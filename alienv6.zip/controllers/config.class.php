<?php
 // @author     Jonathon Maguire, www.coderlite.com, www.thealiennetwork.co.uk
// @coder      Jonathon Maguire, jonathonmaguire@gmail.com
// @version    4.0
// @file		config.class.php
 
 
if(!defined('IN_ROOT')) { die(DOMAIN); }

class config {
	
    public static $beta = false;
    public static $sitename = 'The Alien Network';
}

