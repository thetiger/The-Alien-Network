<div class="container-fluid col-xs-12 col-md-12 test">

    <div class="row">

        <div class="container test whitetext">

            <div class="row">

                <!--Start of page content -->

                <div class="col-lg-12 whitetext stories text-center textindent blackbg">
                    <h1>Ancient Aliens</h1>
                    <hr>
                    <p>
                        Ancient Aliens has proven to be a succesfull hit with 'The History Channel', its amazing insight into just how we may have
                        lived on this earth with aliens in tow is just quite astonishing, follow the whole gang as they try
                        to uncover the hidden truth.
                    </p>
                    <div id="myCarousel" class="carousel slide sliderbg" data-ride="carousel" style="width: 600px; margin: 0 auto">

                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                            <li data-target="#myCarousel" data-slide-to="3"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/HaCsbXxIG_M"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/UsIeMki4pR8"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/cZIUgtDiLu4"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/MpO5baUSDTQ"></iframe>
                                </div>
                            </div>

                            <!-- Left and right controls -->
                            <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
                            <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
                        </div>
                        <br>
                    </div>
                    
                                    <div class="col-xs-12 col-md-12">
                &nbsp;
                </div>

                </div>
                
                <div class="col-xs-12 col-md-12">
                &nbsp;
                </div>

                <div class="col-lg-12 whitetext stories text-center textindent blackbg">
                    <h1>JFK Assassination Conspiracy</h1>
                    <hr>
                    <p>
                        There has been a longtime held belief that the once over John F Kennedy was assassinate whilst being driven through a town
                        in America. These video's delve into the conspiracy and reveal information which brings into disrepute
                        long held beliefs that those who believe he wasn't a target; that even those beliefs are called into
                        question.
                    </p>
                    <div id="myCarousel1" class="carousel slide sliderbg" data-ride="carousel" style="width: 600px; margin: 0 auto">

                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel1" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel1" data-slide-to="1"></li>
                            <li data-target="#myCarousel1" data-slide-to="2"></li>
                            <li data-target="#myCarousel1" data-slide-to="3"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/nLZuPB3uSVw"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/WxrmyfgALUc"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Qi14A20MJbE"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/8a-EPZl__a0"></iframe>
                                </div>
                            </div>

                            <!-- Left and right controls -->
                            <a class="left carousel-control" href="#myCarousel1" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
                            <a class="right carousel-control" href="#myCarousel1" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
                        </div>
                    </div>
                    
                                    <div class="col-xs-12 col-md-12">
                &nbsp;
                </div>

                </div>
                
               <div class="col-xs-12 col-md-12">
                &nbsp;
                </div>
                
                <div class="col-lg-12 whitetext stories text-center textindent blackbg">
                    <h1>9/11 Conspiracy</h1>
                    <hr>
                    <p>
                        The twin towers being bombed by plane is a popular conspiracy that many believe was planned, these videos delve further into
                        this conspiracy.
                    </p>
                    <div id="myCarousel2" class="carousel slide sliderbg" data-ride="carousel" style="width: 600px; margin: 0 auto">

                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel2" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel2" data-slide-to="1"></li>
                            <li data-target="#myCarousel2" data-slide-to="2"></li>
                            <li data-target="#myCarousel2" data-slide-to="3"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/4Nmj6t51Wz8"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/hWiusdy1miI"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/xRpPtuymV24"></iframe>
                                </div>
                            </div>

                            <div class="item">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/-jYMsB-ehok"></iframe>
                                </div>
                            </div>

                            <!-- Left and right controls -->
                            <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
                            <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
                        </div>
                    </div>
                <div class="col-xs-12 col-md-12">
                &nbsp;
                </div>
                </div>
                
                                <div class="col-xs-12 col-md-12">
                &nbsp;
                </div>