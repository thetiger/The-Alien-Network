<div class="container-fluid col-xs-12 col-md-12 footer">

    <div class="row">

        <div class="container">

            <div class="row">

                <div class="col-md-8 logofootermove">
                    <div class="fb-page fb_iframe_widget" data-href="https://www.facebook.com/TheAlienNetworkCom" data-small-header="false" data-adapt-container-width="true"
                        data-hide-cover="false" data-show-facepile="false" data-show-posts="false" fb-xfbml-state="rendered"
                        fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=&amp;container_width=750&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2FTheAlienNetworkCom&amp;locale=en_GB&amp;sdk=joey&amp;show_facepile=false&amp;show_posts=false&amp;small_header=false"><span style="vertical-align: bottom; width: 0px; height: 0px;"><iframe name="f2c05f08d39c92" width="1000px" height="1000px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:page Facebook Social Plugin" src="https://www.facebook.com/v2.4/plugins/page.php?adapt_container_width=true&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2F5oivrH7Newv.js%3Fversion%3D42%23cb%3Df163c098427a3a4%26domain%3Dwww.thealiennetwork.co.uk%26origin%3Dhttps%253A%252F%252Fwww.thealiennetwork.co.uk%252Ff3925354bb88134%26relation%3Dparent.parent&amp;container_width=750&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2FTheAlienNetworkCom&amp;locale=en_GB&amp;sdk=joey&amp;show_facepile=false&amp;show_posts=false&amp;small_header=false" style="border: none; visibility: visible; width: 0px; height: 0px;" class=""></iframe></span></div>
                </div>

                <div class="col-md-4 whitetext footercontent">
                    <footer><span class="glyphicon glyphicon-envelope"></span> <a class="footercontact" href="mailto:support@thealiennetwork.co.uk?Subject=Media%20Enquiry">support@thealiennetwork.co.uk</a>
                        <p>All content is that of the user who posted it, The Alien Network does not take any responsibility
                            for content posted.</p>
                    </footer>
                </div>

            </div>

        </div>

    </div>

</div>