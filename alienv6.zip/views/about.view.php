<div class="container-fluid col-xs-12 col-md-12 test">

    <div class="row">

        <div class="container test whitetext">

            <div class="row">

                <div class="col-xs-12 col-md-12" style="padding:20px;">

                    <div class="col-xs-12 col-md-4">

                        <img class="img-responsive" style="-webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 10px;"
                         src="https://scontent-lht6-1.xx.fbcdn.net/v/t1.0-9/14202513_10208297619251734_4731360180490906157_n.jpg?oh=6ea4c10f4cccd4895adce1dd30d6a550&oe=5A45D747">

                    </div>

                    <div class="col-xs-12 col-md-8">
                    <h2>Who am I?</h1>
                    <h5>I am a webdeveloper from the North of England, I have always had an interest in the 'unknown' and the 'what-ifs' of the world.</h5>
                    <h2>What is the purpose for The Alien Network?</h2>
                    <h5>The Alien Network is meant as a platform for indepent free-speech in terms of those topics deemed as 'conspiracy'.<br><br> The aim is to have a community
                    of like-minded individuals who contribute to the growth of The Alien Network and to provide valuable insight into topics within which they have researched 
                    or have been part of in.
                    </h5>
                    <h2>History</h2>
                    <h5>The Alien Network was founded in 2015.</h5>
                    <h2>Technologies we use</h2>
                    <h5>The Alien Network is built in PHP/MySQL/HTML5/CSS3/Jquery.</h5>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>